#!/usr/bin/env python3
"""潮声之下：双人局域网中继。Python 3.8+，无第三方依赖。
将本文件与游戏 HTML 放在同一目录，运行 python 联机服务器.py [8123]。
"""
import argparse
import base64
import hashlib
import json
import os
import socket
import struct
import threading
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlsplit

GAME_DIR = Path(__file__).resolve().parent
GAME_NAME = '潮声之下_深渊潜航3D_v22.html'
MAX_MESSAGE = 2 * 1024 * 1024
ROOM_LIMIT = 2
rooms = {}
room_lock = threading.RLock()


def read_exact(stream, size):
    parts = bytearray()
    while len(parts) < size:
        chunk = stream.read(size - len(parts))
        if not chunk:
            raise EOFError('连接已关闭')
        parts.extend(chunk)
    return bytes(parts)


class Peer:
    def __init__(self, handler):
        self.conn = handler.connection
        self.stream = handler.rfile
        self.send_lock = threading.Lock()
        self.id = uuid.uuid4().hex
        self.room = None
        self.alive = True

    def frame(self, data=b'', opcode=1):
        if isinstance(data, str):
            data = data.encode('utf-8')
        n = len(data)
        header = bytes([0x80 | opcode])
        header += bytes([n]) if n < 126 else (b'\x7e' + struct.pack('!H', n) if n < 65536 else b'\x7f' + struct.pack('!Q', n))
        with self.send_lock:
            try:
                self.conn.sendall(header + data)
            except OSError:
                self.alive = False
                try:
                    self.conn.shutdown(socket.SHUT_RDWR)
                except OSError:
                    pass
                raise

    def send(self, obj):
        self.frame(json.dumps(obj, ensure_ascii=False, separators=(',', ':')))

    def receive(self):
        payload = bytearray()
        fragmented = False
        while True:
            a, b = read_exact(self.stream, 2)
            fin, opcode = bool(a & 128), a & 15
            if a & 112 or not b & 128:
                raise ValueError('非法 WebSocket 帧')
            n = b & 127
            if n == 126:
                n = struct.unpack('!H', read_exact(self.stream, 2))[0]
            elif n == 127:
                n = struct.unpack('!Q', read_exact(self.stream, 8))[0]
            if n > MAX_MESSAGE or (opcode < 8 and len(payload) + n > MAX_MESSAGE):
                raise ValueError('消息过大')
            if opcode >= 8 and (not fin or n > 125):
                raise ValueError('非法控制帧')
            mask = read_exact(self.stream, 4)
            raw = read_exact(self.stream, n)
            data = bytes(v ^ mask[i % 4] for i, v in enumerate(raw))
            if opcode == 8:
                self.frame(data, 8)
                raise EOFError('对方离开')
            if opcode == 9:
                self.frame(data, 10)
                continue
            if opcode == 10:
                continue
            if opcode == 1 and not fragmented:
                payload.extend(data)
                fragmented = not fin
            elif opcode == 0 and fragmented:
                payload.extend(data)
            else:
                raise ValueError('不支持的帧类型')
            if fin:
                return json.loads(payload.decode('utf-8'))


def send_safe(peer, message):
    try:
        peer.send(message)
    except OSError:
        pass


def members_message(room):
    peers = rooms.get(room, {})
    ids = list(peers)
    return {'t': 'members', 'room': room, 'members': ids, 'host': ids[0] if ids else None}


def join(peer, msg):
    room = msg.get('room', '')
    if not isinstance(room, str) or not 1 <= len(room.strip()) <= 48:
        send_safe(peer, {'t': 'error', 'message': '房间号须为 1—48 个字符'})
        return
    room = room.strip().upper()
    with room_lock:
        if peer.room is not None:
            send_safe(peer, {'t': 'error', 'message': '已在房间中，请断开后再加入'})
            return
        if len(rooms.get(room, {})) >= ROOM_LIMIT:
            send_safe(peer, {'t': 'error', 'message': '房间已满（最多两人）'})
            return
        peers = rooms.setdefault(room, {})
        peers[peer.id] = peer
        peer.room = room
        # 房间元数据与加入回执有固定顺序；状态消息使用发送者的固定 ID。
        send_safe(peer, {'t': 'joined', 'room': room, 'idx': peer.id, 'protocol': 2})
        update = members_message(room)
        for p in peers.values():
            send_safe(p, update)
    print('[联机] 加入', room, peer.id[:8], flush=True)


def leave(peer):
    with room_lock:
        peers = rooms.get(peer.room)
        if peers is None:
            return
        peers.pop(peer.id, None)
        update = members_message(peer.room)
        for p in peers.values():
            send_safe(p, {'t': 'left', 'idx': peer.id})
            send_safe(p, update)
        if not peers:
            rooms.pop(peer.room, None)
    print('[联机] 离开', peer.room, peer.id[:8], flush=True)


class Handler(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'

    def do_GET(self):
        if self.headers.get('Upgrade', '').lower() == 'websocket':
            return self.websocket()
        path = unquote(urlsplit(self.path).path)
        # 仅提供游戏页面，避免意外把同目录的私人文件暴露到局域网。
        if path not in ('/', '/' + GAME_NAME):
            self.send_error(404, 'Not found')
            return
        target = GAME_DIR / GAME_NAME
        if not target.is_file():
            self.send_error(404, 'Place the game HTML beside this Python file')
            return
        data = target.read_bytes()
        self.send_response(200)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(data)

    def websocket(self):
        if urlsplit(self.path).path != '/ws':
            self.send_error(404)
            return
        key = self.headers.get('Sec-WebSocket-Key', '')
        try:
            if len(base64.b64decode(key, validate=True)) != 16:
                raise ValueError()
        except Exception:
            self.send_error(400, 'Invalid WebSocket key')
            return
        if self.headers.get('Sec-WebSocket-Version') != '13':
            self.send_error(400, 'WebSocket version 13 required')
            return
        accept = base64.b64encode(hashlib.sha1((key + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11').encode()).digest()).decode()
        self.send_response(101)
        self.send_header('Upgrade', 'websocket')
        self.send_header('Connection', 'Upgrade')
        self.send_header('Sec-WebSocket-Accept', accept)
        self.end_headers()
        self.wfile.flush()
        self.close_connection = True
        self.connection.settimeout(45)  # 网页每 10 秒心跳；中断连接可回收房间。
        peer = Peer(self)
        try:
            while peer.alive:
                msg = peer.receive()
                if not isinstance(msg, dict):
                    continue
                kind = msg.get('t')
                if kind == 'join':
                    join(peer, msg)
                elif kind == 'ping':
                    peer.send({'t': 'pong'})
                elif kind in {'state', 'dmg', 'kill', 'hello', 'world', 'start', 'pickup'}:
                    with room_lock:
                        peers = rooms.get(peer.room, {})
                        recipients = [p for p in peers.values() if p is not peer]
                    if not peer.room:
                        peer.send({'t': 'error', 'message': '请先加入房间'})
                        continue
                    msg['idx'] = peer.id
                    for p in recipients:
                        send_safe(p, msg)
        except (EOFError, OSError, ValueError, UnicodeError):
            pass
        finally:
            peer.alive = False
            leave(peer)

    def log_message(self, fmt, *args):
        if args and str(args[1] if len(args) > 1 else '') not in ('200', '101'):
            super().log_message(fmt, *args)


class Server(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('port', nargs='?', type=int, default=8123)
    port = parser.parse_args().port
    if not (1 <= port <= 65535):
        parser.error('端口范围为 1—65535')
    try:
        server = Server(('0.0.0.0', port), Handler)
    except OSError as exc:
        print('启动失败：', exc, '\n可换端口：python 联机服务器.py 8124')
        return 1
    addresses = set()
    try:
        addresses.update(socket.gethostbyname_ex(socket.gethostname())[2])
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as probe:
            probe.connect(('8.8.8.8', 80))
            addresses.add(probe.getsockname()[0])
    except OSError:
        pass
    print('潮声之下 · 双人局域网服务器（修复版）')
    print('本机： http://127.0.0.1:' + str(port))
    for ip in sorted(addresses):
        if not ip.startswith('127.'):
            print('同一局域网的另一台设备： http://' + ip + ':' + str(port))
    print('两人打开网页 → 创建/加入相同房间 → 选择相同模式与关卡 → 各自开始下潜。')
    print('保持此窗口开启；Windows 防火墙弹窗请允许“专用网络”。Ctrl+C 停止。', flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print('\n服务器已停止')
    finally:
        server.server_close()
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
