@echo off
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 goto python
py -3 "联机服务器.py"
goto end
:python
where python >nul 2>nul
if errorlevel 1 goto missing
python "联机服务器.py"
goto end
:missing
echo 未找到 Python，请先安装 Python 3.8 或更高版本并勾选添加到 PATH。
:end
pause
